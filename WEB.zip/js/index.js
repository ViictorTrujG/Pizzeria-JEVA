// Obtenir l'idioma de la URL si existeix i executar la funció "changeLanguage"
const querystring = window.location.search; // Si la url és: https://miweb.es?lang=es , retorna ?lang=es
const urlParams = new URLSearchParams(querystring);
if (urlParams.get('lang')){
  const lang = urlParams.get('lang');
  changeLanguage(lang);
}

async function changeLanguage(lang) {
  // Guardar l'idioma a la URL
  const newURL = window.location.protocol + '//' + window.location.host + window.location.pathname + '?lang=' + lang;
  window.history.replaceState({}, '', newURL);

  // Obtenir el fitxer json corresponent
  const response = await fetch(`./i18n/${lang}.json`);
  const data = await response.json();

  // Canviar els texts (Aquesta és la part que heu de modificar)

  document.getElementById('tituloPizzasNuestraCarta').innerHTML = data.tituloPizzasNuestraCarta;

  document.getElementById('tituloRestaurantes').innerHTML = data.tituloRestaurantes;

  document.getElementById('tituloIdioma').innerHTML = data.tituloIdioma;

  document.getElementById('columna1').innerHTML = data.columna1;
  document.getElementById('t_ofertas').innerHTML = data.t_ofertas; 
  document.getElementById('t_menus').innerHTML = data.t_menus; 
  document.getElementById('t_pizzas').innerHTML = data.t_pizzas;
  document.getElementById('t_entrantes').innerHTML = data.t_entrantes;
  document.getElementById('t_bebidas').innerHTML = data.t_bebidas;
  document.getElementById('t_postres').innerHTML = data.t_postres;

  document.getElementById('columna2').innerHTML = data.columna2;          
  document.getElementById('t_calidad').innerHTML = data.t_calidad; 
  document.getElementById('t_listado').innerHTML = data.t_listado;
  document.getElementById('t_valores').innerHTML = data.t_valores;
  document.getElementById('t_tiendas').innerHTML = data.t_tiendas;
  document.getElementById('t_masas').innerHTML = data.t_masas;
  document.getElementById('t_pizzasingluten').innerHTML = data.t_pizzassingluten;
  document.getElementById('t_pizzasgourmet').innerHTML = data.t_pizzasgourmet;
         
  document.getElementById('columna3').innerHTML = data.columna3;
  document.getElementById('t_acerca').innerHTML = data.t_acerca;
  document.getElementById('t_trabajaconnosotros').innerHTML = data.t_trabajaconnosotros;
  document.getElementById('t_franquicia').innerHTML = data.t_franquicia;

  document.getElementById('columna4').innerHTML = data.columna4;
  document.getElementById('t_condicionesgenerales').innerHTML = data.t_condicionesgenerales;
  document.getElementById('t_politicaprivacidad').innerHTML = data.t_politicaprivacidad;
  document.getElementById('t_politicacookies').innerHTML = data.t_politicacookies;
  document.getElementById('t_condicionespromocionales').innerHTML = data.t_condicionespromocionales;
  document.getElementById('t_prevencion').innerHTML = data.t_prevencion;

  document.getElementById('columna5').innerHTML = data.columna5;
  document.getElementById('t_localizador').innerHTML = data.t_localizador;
  document.getElementById('t_contacto').innerHTML = data.t_contacto;
  document.getElementById('t_preguntasfrecuentes').innerHTML = data.t_preguntasfrecuentes;
  document.getElementById('t_covid').innerHTML = data.t_covid;



}

