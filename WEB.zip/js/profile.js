// Obtenir l'idioma de la URL si existeix i executar la funció "changeLanguage"
const querystring = window.location.search; // Si la url és: https://miweb.es?lang=es , retorna ?lang=es
const urlParams = new URLSearchParams(querystring);
if (urlParams.get('lang')){
  const lang = urlParams.get('lang');
  changeLanguage(lang);
}

async function changeLanguage(lang) {
  // Guardar l'idioma a la URL
  const newURL = window.location.protocol + '//' + window.location.host + window.location.pathname + '?lang=' + lang;
  window.history.replaceState({}, '', newURL);

  // Obtenir el fitxer json corresponent
  const response = await fetch(`../i18n/${lang}.json`);
  const data = await response.json();

  // Canviar els texts (Aquesta és la part que heu de modificar)

  document.getElementById('barrausuario').placeholder = data.barrausuario.placeholder;

  document.getElementById('barrapassword').placeholder = data.barrapassword.placeholder;

  document.getElementById('recuperarcontraseña').innerHTML = data.recuperarcontraseña;

  document.getElementById('ENTRAR').innerHTML = data.ENTRAR;

  document.getElementById('aunnotienescuenta').innerHTML = data.aunnotienescuenta;

  document.getElementById('registrate').innerHTML = data.registrate;

  document.getElementById('oiniciasesion').innerHTML = data.oiniciasesion;


}